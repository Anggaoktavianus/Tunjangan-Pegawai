<?php

function cek_user($id){
	
	$ci = get_instance();
	return $ci->db->query("SELECT * from user where id = '$id'")->row();
}

?>