<!-- Sidebar -->

  <?php if($this->session->userdata('role') == 'admin'){
        echo "admin";
    }else{
        echo "customer";
    }

    ?>
<ul class="sidebar navbar-nav">
    <li class="nav-item <?php echo $this->uri->segment(2) == '' ? 'active': '' ?>">
        <a class="nav-link" href="<?php echo site_url('admin') ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

 <?php if($this->session->userdata('role') == 'admin'){ ?>
    <li class="nav-item dropdown <?php echo $this->uri->segment(2) == 'pegawais' ? 'active': '' ?>">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
            aria-expanded="false">
            <i class="fas fa-fw fa-boxes"></i>
            <span>Data Pegawai</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="<?php echo site_url('admin/pegawais/add') ?>">Tambah Pegawai</a>
            <a class="dropdown-item" href="<?php echo site_url('admin/pegawais') ?>">List Pegawai</a>
        </div>
    </li>
 
    <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('admin') ?>">
            <i class="fas fa-fw fa-folder-open"></i>
            <span>Manajemen Data Izin</span>
        </a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link" href="#">
            <i class="fas fa-fw fa-file-alt"></i>
            <span>Konfirmasi Izin</span></a>
    </li>

       <li class="nav-item">
        <a class="nav-link" href="#">
            <i class="fas fa-fw fa-users"></i>
            <span>Management Admin</span></a>
    </li>
       <?php }else{
        echo "customer";
    }

    ?>
      <li class="nav-item">
        <a class="nav-link" href="">
            <i class="fas fa-fw fa-folder-open"></i>
            <span>Data Izin</span>
        </a>
    </li>

</ul>
